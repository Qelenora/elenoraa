function charCount(str, char) {
  let lowerStr = str.toLowerCase();
  let lowerChar = char.toLowerCase();

  let count = 0;
  for (let i = 0; i < lowerStr.length; i++) {
    if (lowerStr[i] === lowerChar) {
      count++;
    }
  }

  return count;
}

console.log(charCount("Abrakadabra", "a"));
console.log(charCount("hello", "z"));
console.log(charCount("Elenora", "e"));
console.log(charCount("қанағаттандырылмағандықтарыңыздан", "ы"));
