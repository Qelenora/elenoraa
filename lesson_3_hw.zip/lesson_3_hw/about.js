let input = prompt("Введите число от 2 до 10");
let number = parseInt(input);

if (number >= 2 && number <= 10) {
  for (let i = 1; i <= 10; i++) {
    let result = number * i;
    console.log(number + " × " + i + " = " + result);
  }
} else {
  console.error("Ошибка! Введите число от 2 до 10.");
}
