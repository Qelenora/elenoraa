//есть массив оценок по 100-бальной
//шкале [40, 55, 22, 89, 14, 78, 56, 47, 59],
//нужно их перевести в 5-ти бальную систему.
//До 20 баллов это 1, до 40 баллов - это 2,
// до 60 баллов - это 3, до 80 баллов - это 4,
// до 100 баллов это - 5.

let scores = [40, 55, 22, 89, 14, 78, 56, 47, 59];
let grades = [];

// пробежка по всему массиву
// цикл(счетчик;условие выхода из цикла; условие обновления )
/* for (let i = 0; i < scores.length; i++) {
  let score = scores[i];
  let grade;

  switch (scores) {
    case score <= 20:
      grade = 1;
      break;
    case score <= 40:
      grade = 2;
      break;
    case score <= 60:
      grade = 3;
      break;
    case score <= 80:
      grade = 4;
      break;
    default:
      grade = 5;
      break;
  }
}
console.log("Оценки по 5-бальной системе:", grades);*/

for (let i = 0; i < scores.length; i++) {
  let score = scores[i];
  let grade;
  if (score <= 20) {
    grade = 1;
  } else if (score <= 40) {
    grade = 2;
  } else if (score <= 60) {
    grade = 3;
  } else if (score <= 80) {
    grade = 4;
  } else {
    grade = 5;
  }
}

console.log("Оценки по 5-бальной системе:", grades);

// не работает
