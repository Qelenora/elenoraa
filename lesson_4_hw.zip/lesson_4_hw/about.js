function hidePhone(phoneNumber) {
  if (phoneNumber.length <= 2) {
    return phoneNumber;
  }

  let secretPhone = phoneNumber.slice(0, -2) + "xx";

  return secretPhone;
}

console.log(hidePhone("+996 555 123 123"));
console.log(hidePhone("+996 707 262 628"));
